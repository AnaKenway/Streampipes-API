## Data Reader

<p align="center"> 
    <img src="icon.png" width="150px;" class="pe-image-documentation"/>
</p>

***

## Description
Random data generator for temperature and pression.

***

## Output
Data in Json Array
